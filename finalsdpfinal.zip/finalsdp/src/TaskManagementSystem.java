// Singleton Pattern
class TaskOutputManager {
    private static TaskOutputManager instance;

    private TaskOutputManager() {}

    public static TaskOutputManager getInstance() {
        if (instance == null) {
            instance = new TaskOutputManager();
        }
        return instance;
    }

    public void outputTask(Task task) {
        System.out.println("Task Output: " + task.getDescription());
    }
}
// Strategy Pattern
interface TaskManipulationStrategy {
    void manipulateTask(Task task);
}

class BasicTaskManipulationStrategy implements TaskManipulationStrategy {
    private String action;

    public BasicTaskManipulationStrategy(String action) {
        this.action = action;
    }

    @Override
    public void manipulateTask(Task task) {
        System.out.println(action + " task: " + task.getDescription());
    }
}
// Decorator Pattern
interface Task {
    String getDescription();
}

class SimpleTask implements Task {
    private String description;

    public SimpleTask(String description) {
        this.description = description;
    }

    @Override
    public String getDescription() {
        return description;
    }
}

class PriorityDecorator implements Task {
    private Task decoratedTask;
    private String priority;

    public PriorityDecorator(Task decoratedTask, String priority) {
        this.decoratedTask = decoratedTask;
        this.priority = priority;
    }

    @Override
    public String getDescription() {
        return decoratedTask.getDescription() + ", Priority: " + priority;
    }
}
// adapter pattern
interface TaskAdapter {
    void performTaskOperation();
    void handleChallenge();
}

class TaskAdapterImpl implements TaskAdapter {
    @Override
    public void performTaskOperation() {
        System.out.println("Performing task operation");
    }

    @Override
    public void handleChallenge() {
        System.out.println("Handling challenge");
    }
}
//observer
interface TaskObserver {
    void notifyTaskEdited(Task task);
}

class TaskEditingObserver implements TaskObserver {
    @Override
    public void notifyTaskEdited(Task task) {
        System.out.println("Task edited: " + task.getDescription());
    }
}

// Factory Method Pattern
interface TaskFactory {
    Task createTask(String description);
}

class SimpleTaskFactory implements TaskFactory {
    @Override
    public Task createTask(String description) {
        return new SimpleTask(description);
    }
}

public class TaskManagementSystem {
    public static void main(String[] args) {
        // Singleton
        TaskOutputManager outputManager = TaskOutputManager.getInstance();

        // Strategy
        TaskManipulationStrategy addStrategy = new BasicTaskManipulationStrategy("Adding");
        TaskManipulationStrategy editStrategy = new BasicTaskManipulationStrategy("Editing");
        TaskManipulationStrategy deleteStrategy = new BasicTaskManipulationStrategy("Deleting");

        // Decorator
        Task task = new SimpleTask("Finish project");
        task = new PriorityDecorator(task, "Low");

        // Adapter
        TaskAdapter adapter = new TaskAdapterImpl();

        // Observer
        TaskObserver taskObserver = new TaskEditingObserver();

        // Factory
        TaskFactory taskFactory = new SimpleTaskFactory();
        Task newTask = taskFactory.createTask("Do Homework");

        // Using the patterns
        outputManager.outputTask(task);
        addStrategy.manipulateTask(newTask);
        editStrategy.manipulateTask(newTask);
        System.out.println(((PriorityDecorator) task).getDescription());
        adapter.performTaskOperation();
        adapter.handleChallenge();
        taskObserver.notifyTaskEdited(newTask);
        deleteStrategy.manipulateTask(newTask);
    }
}
